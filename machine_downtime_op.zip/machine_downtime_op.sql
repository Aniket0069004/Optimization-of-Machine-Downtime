CREATE DATABASE downtime_db;
USE downtime_db;

CREATE TABLE machine_downtime (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATETIME,
    machine_id VARCHAR(50),
    assembly_line_no VARCHAR(50),
    hydraulic_pressure FLOAT,
    coolant_pressure FLOAT,
    air_system_pressure FLOAT,
    coolant_temperature FLOAT,
    hydraulic_oil_temp FLOAT,
    spindle_bearing_temp FLOAT,
    tool_vibration FLOAT,
    spindle_speed INT,
    voltage FLOAT,
    torque FLOAT,
    cutting_kn FLOAT,
    downtime_reason VARCHAR(50)
);
USE downtime_db;
SELECT * FROM machine_downtime LIMIT 10;
INSERT INTO machine_downtime (date, machine_id, assembly_line_no, hydraulic_pressure, coolant_pressure, air_system_pressure, coolant_temperature, hydraulic_oil_temp, spindle_bearing_temp, tool_vibration, spindle_speed, voltage, torque, cutting_kn, downtime_reason)
VALUES
('2022-03-31 00:00:00', 'Makino-L1-Unit1-2013', 'Shopfloor-L1', 71.04, 6.93372, 6.28496, 25.6, 46, 33.4, 26.492, 25892, 230.5, 120.3, 15.8, 'Overheating'),
('2022-03-31 00:00:00', 'Makino-L3-Unit1-2015', 'Shopfloor-L3', 125.33, 4.03689, 6.19673, 35.3, 47.4, 34.6, 25.274, 19856, 229.8, 118.9, 14.6, 'Power Failure'),
('2022-03-31 00:00:00', 'Makino-L2-Unit1-2014', 'Shopfloor-L2', 71.12, 6.83941, 6.65553, 30.3, 40.7, 33, 30.608, 19851, 228.9, 119.5, 13.9, 'Tool Wear'),
('2022-03-31 00:00:00', 'Makino-L3-Unit1-2015', 'Shopfloor-L3', 139.34, 4.57348, 6.56039, 20.1, 44.2, 40.4, 30.791, 18461, 227.5, 117.8, 14.3, 'Coolant Failure'),
('2022-03-31 00:00:00', 'Makino-L1-Unit1-2013', 'Shopfloor-L1', 137.37, 5.91836, 7.22807, 5.4, 47.3, 32.7, 25.597, 27513, 230.1, 120.1, 15.2, 'Overheating');

SELECT * FROM machine_downtime LIMIT 10;

